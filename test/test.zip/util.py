import sys
import os
import glob
import sh


def splitext(wav_name):
    name = wav_name.split(".")

    return name
